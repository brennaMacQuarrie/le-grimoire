// export default async getUser (req, res) => {
//     // save in a variable, the User schema, or multiples?
//     // when is it a single user model and when is it the full body?
//     const users = await User.find();
//     res.json(users);
// }